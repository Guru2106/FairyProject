var fairy, fairyImg;
var star, starImg;
var starnight, starnightImg;

function preload() {
  
   fairyImg = loadImage("fairy1.png");
   starImg = loadImage("star.png");
   starnightImg = loadImage("starnight.png");
  
}

function setup() {
	createCanvas(800, 750);
    
    starnight = createSprite(160, 40);
    starnight.addImage("starnightImg", starnightImg);
    starnight.scale = 1;
  
    fairy = createSprite(60, 60);
    fairy.addImage("fairyImg", fairyImg);
    fairy.scale = 0.2;
  
    star = createSprite(500, 40);
    star.addImage("starImg", starImg);
    star.scale = 0.2;

    
}


function draw() {
  background(250);
  
  fairy.velocityX = 1;
  star.velocityX = -2;
  
  if(star.isTouching(fairy)) {
    star.velocityX = 0;
    fairy.velocityX = 0;
  }
  
  
  drawSprites();

}
